algoritmo_gen<-function(Base,repeticiones,pobla,n_dias){
  
  Hist_ED=array(dim=c(4,6,repeticiones))
  Hist_CR=array(dim=c(4,6,repeticiones))
  
  for(i in 1:repeticiones){
    I_R=do.call(estimacion_parametros,list(Base,n_dias,pobla))
    
    Parametros_ED_R=I_R[[1]]
    Parametros_ED_R[2,]=abs(Parametros_ED_R[2,])
    Parametros_CR_R=I_R[[2]]
    Parametros_CR_R[2,]=abs(Parametros_CR_R[2,])
    hist_Convergencia_R=I_R[[3]]
    proy_tasa_R=I_R[[4]]
    Errores_R=I_R[[5]]
    DifRegresion_Lineal_R=I_R[[6]]
    Evolucion_ED_R=I_R[[7]]
    Evolucion_CR_R=I_R[[8]]
    F_R=ultima_variacion(Evolucion_CR_R,Evolucion_ED_R)
    
    colnames(Parametros_ED_R)=names(TC_historica)[-1]
    colnames(Parametros_CR_R)=names(TC_historica)[-1]
    Hist_ED[,,i]=Parametros_ED_R
    Hist_CR[,,i]=Parametros_CR_R
    write.csv(Parametros_ED_R,paste("ED_Parametros_Ejecucion_",i,".csv",sep=""),row.names = FALSE)
    write.csv(Parametros_CR_R,paste("CR_Parametros_Ejecucion_",i,".csv",sep=""),row.names = FALSE)
    write.csv(Evolucion_ED_R,paste("ED_Evolucion_Ejecucion_",i,".csv",sep=""),row.names = FALSE)
    write.csv(Evolucion_CR_R,paste("CR_Evolucion_Ejecucion_",i,".csv",sep=""),row.names = FALSE)
    print(i)
  }
  return(list(Hist_ED,Hist_CR,DifRegresion_Lineal_R,proy_tasa_R))
  
}
