setwd("C:/Users/actag/Desktop/Proyecto Final IA")

library("readxl")
library("dplyr")
library(xlsx)


diaval="30"
mesval="10"
añoval="2021"
saltos="diario"
nsim=1000
num_ejercicios=20

diasproy=seq(as.Date(paste(diaval,"/",mesval,"/",añoval,sep=""),"%d/%m/%Y"),as.Date(paste(diaval,"/",mesval,"/",as.numeric(añoval)+1,sep=""),"%d/%m/%Y"),by="day")
diasproy=diasproy[!weekdays(diasproy)%in%c("sábado","domingo")]
n_dias=length(diasproy)

Instrumentos=dir()
nInstrumentos=length(Instrumentos)
TR_historica=crear_historico(Instrumentos)
TC_historica=TR_historica[[1]]
TR_historica=TR_historica[[2]]

Parametros=do.call("algoritmo_gen",list(TC_historica,100,1000,n_dias))
Parametros_ED=Parametros[[1]]
Parametros_CR=Parametros[[2]]
DifRegresion_Lineal_R=Parametros[[3]]
proy_tasa_R=Parametros[[4]]

Prueba_Hipotesis=do.call("prueba_p_medias",list(Parametros_ED,Parametros_CR,nInstrumentos))
Parametros=seleccion_modelo(Parametros_ED,Parametros_CR,Prueba_Hipotesis)[[1]]
Tasas_Proyectadas=crear_curva(TC_historica,diasproy,nsim,nInstrumentos,n_dias,Parametros,DifRegresion_Lineal_R,proy_tasa_R)


Activo=1

plot((as.numeric(TR_historica[1:510,Activo+1])),type="l",main="Tasa",xlab="Historia",ylab="Tasa",xlim=c(1,530),ylim=c(0,.1))

for(i in 1:100){
  lines(c(rep(NA,510),cumprod(Tasas_Proyectadas[1:20,Activo,i])*TR_historica[510,Activo+1]),col="ROYALBLUE")
}

