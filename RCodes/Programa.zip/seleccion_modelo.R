seleccion_modelo<-function(P1,P2,BP){
  Param=matrix(0,4,length(BP))
  mitad=round(dim(P1)[3]/2,0)
  escoger=c()
  for(i in 1:length(BP)){
    if(BP[i]=="ED"){
      Param[,i]=P1[,i,order(P1[4,i,],decreasing = TRUE)[mitad]]
      escoger[i]="ED"
    }else if(BP[i]=="CR"){
      Param[,i]=P2[,i,order(P2[4,i,],decreasing = TRUE)[mitad]]
      escoger[i]="CR"
    }else if(BP[i]=="Iguales"){
      if(sample(1:2,1)==1){
        Param[,i]=P1[,i,order(P1[4,i,],decreasing = TRUE)[mitad]]
        escoger[i]="ED"
      }else{
        Param[,i]=P2[,i,order(P2[4,i,],decreasing = TRUE)[mitad]]
        escoger[i]="CR"
      }
    }
  }
  return(list(Param,escoger))
}
