prueba_p_medias<-function(muestra1,muestra2,instrumentos){
  Resultado=c()
  for(i in 1:instrumentos){
    Prueba=wilcox.test(x =muestra1[4,i,] , y =muestra2[4,i,] , alternative = "two.sided")
    if(Prueba$p.value<.05){
      Prueba1=wilcox.test(x =muestra1[4,i,] , y =muestra2[4,i,] , alternative = "less")
      if(Prueba1$p.value<.05){
        Resultado[i]="CR"
      }else{
        Resultado[i]="ED"
      }
    }else{
      Resultado[i]="Iguales"
    }
  }
  return(Resultado)
}
