crear_historico<-function(Instrumentos){
  nInstrumentos=length(Instrumentos)
  for(i in 1:length(Instrumentos)){
    if(i==1){
      TR_historica=read.csv(Instrumentos[i])[214:724,2:3]
      TR_historica[,2]=TR_historica[,2]/100
    }else{
      Aux=read.csv(Instrumentos[i])
      TR_historica=cbind(TR_historica,Aux[match(TR_historica[,1],Aux[,2]),3]/100)
      rm(Aux)
    }
    
  }
  TR_historica=data.frame(TR_historica)
  names(TR_historica)=c("FECHA",gsub(".csv","",Instrumentos))
  TC_historica=TR_historica
  TC_historica[2:511,2:7]=TC_historica[2:511,2:7]/TC_historica[1:510,2:7]
  TC_historica=TC_historica[-1,]

  return(list(TC_historica,TR_historica))
}
