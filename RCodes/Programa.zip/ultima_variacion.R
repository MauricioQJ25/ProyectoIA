ultima_variacion<-function(Base,Base2){
  Final0=matrix(0,2,dim(Base)[2]/4)
  iterador=seq(4,dim(Base)[2],4)
  for( i in 1:(dim(Base)[2]/4)){
    Final0[1,i] =max((1:(dim(Base)[1]-1))[Base[2:dim(Base)[1],iterador[i]]!= Base[1:(dim(Base)[1]-1),iterador[i]]])
    Final0[2,i] =max((1:(dim(Base2)[1]-1))[Base2[2:dim(Base2)[1],iterador[i]]!= Base2[1:(dim(Base2)[1]-1),iterador[i]]])
  }
  
  Final1=matrix(0,2,dim(Base)[2]/4)
  iterador=seq(4,dim(Base)[2],4)
  for( i in 1:(dim(Base)[2]/4)){
    Final1[1,i] =max((1:(dim(Base)[1]-1))[(Base[2:dim(Base)[1],iterador[i]]- Base[1:(dim(Base)[1]-1),iterador[i]])>.0000001])
    Final1[2,i] =max((1:(dim(Base2)[1]-1))[(Base2[2:dim(Base2)[1],iterador[i]]- Base2[1:(dim(Base2)[1]-1),iterador[i]])>.0000001])
  }
  return(list(Final0,Final1))
}
