crear_curva<-function(Base,diasproy,nsim,nInstrumentos,n_dias,Parametros_ED,DifRegresion_Lineal,proy_tasa){
  
  Inicio_Proyeccion=Base[dim(Base)[1],-1]
  
  CurvasProy_Lineal_ED=array(data=0,dim=c(length(diasproy)+1,dim(Base)[2]-1,nsim))
  CurvasProyST_Lineal_ED=array(data=0,dim=c(length(diasproy)+1,dim(Base)[2]-1,nsim))

  t=1/252
  
  for (i in 1:nsim){
    tiempo=1:(n_dias)
    SimCorrNorm=t(matrix(rnorm(n_dias*nInstrumentos,0,1),nInstrumentos,n_dias))
    
    CurvasProyST_Lineal_ED[2:(n_dias+1),,i]=((
                                                matrix(as.numeric(rep(Parametros_ED[3,],n_dias)),n_dias,nInstrumentos,byrow = TRUE)+ 
                                                  
                                                matrix(rep(as.numeric(-Parametros_ED[3,]) ,n_dias),n_dias,nInstrumentos,byrow = T)*
                                                exp(-as.matrix(tiempo,1,n_dias)%*%t(as.matrix(as.numeric(Parametros_ED[1,]),nInstrumentos,1))*t)
                                                
                                                
                                              +(((matrix(rep(as.numeric(Parametros_ED[2,]) ,n_dias),n_dias,nInstrumentos,byrow = T)*
                                                    (((1-exp(-as.matrix(tiempo,1,n_dias)%*%t(as.matrix(as.numeric(Parametros_ED[1,]),nInstrumentos,1))*(2*t)))^(1))/
                                                       (matrix(rep(((2*as.numeric(Parametros_ED[1,]))^1),n_dias),n_dias,nInstrumentos,byrow = T)))^(.5)))*SimCorrNorm)))
    

  }
  
  CurvasProy_Lineal_ED[2:(n_dias+1),,]=array(rep(proy_tasa,nsim),dim=c(n_dias,nInstrumentos,nsim))+CurvasProyST_Lineal_ED[2:(n_dias+1),,]


  
  CurvasProy_Lineal_ED[1,,]=matrix(rep(as.numeric(Inicio_Proyeccion),rep(nsim,dim(Base)[2]-1)),dim(Base)[2]-1,nsim,T)


  

  
  return(CurvasProy_Lineal_ED)
  
  
  
}
